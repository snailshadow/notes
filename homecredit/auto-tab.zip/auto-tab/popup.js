document.getElementById('run').onclick = function () {
    time = document.getElementById('time').value;
    time = parseInt(time);
    chrome.extension.getBackgroundPage().setTime(time);
    chrome.extension.getBackgroundPage().run();
}


document.getElementById('stop').onclick=function(){
    chrome.extension.getBackgroundPage().stop();
}

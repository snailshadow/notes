﻿var length = 0;
var i = 0;
var tab = null;
var time = 15000;
var timer = null;

function setTime(t) {
    console.log('切换秒数'+t)
    time = t * 1000;
}

function run() {
    console.log('run');
    chrome.tabs.getAllInWindow(null, function (tabs) {
        length = tabs.length;
        tab = tabs[0];
    });  
    if (timer == null) {
        console.log('setInterval');
        timer = setInterval(() => {
            chrome.tabs.highlight({ windowId: tab.windowId, tabs: i });
            i++;
            console.log(i, length);
            if (i == length) i = 0;
        }, time); 
    }
    
}

function stop() {
    console.log('stop');
    clearInterval(timer);
    timer = null;
}

#!/bin/bash

dist_container_name="query-exporter-sas"
dist_container=`docker ps -a|grep ${dist_container_name}`
port=9564

echo "[${dist_container}]"

function re_create_container(){

    
    if [[ X"" != X"${dist_container}" ]];then
        echo "Remove old container ${dist_container_name}"
        docker rm ${dist_container_name} -f
    fi
    
    echo "Start container ${dist_container_name}"
    docker run -itd \
    --name ${dist_container_name} \
    --rm \
    --log-driver=loki \
    --log-opt loki-url="http://10.67.231.24:3100/loki/api/v1/push" \
    --log-opt loki-retries=5 \
    --log-opt loki-batch-size=400 \
    -p ${port}:9560/tcp \
    -e NLS_LANG=AMERICAN_AMERICA.UTF8 \
    -v /etc/localtime:/etc/localtime:ro \
    adonato/query-exporter:2.7.0 \
    --log-level=DEBUG
    
    echo "Re-configure ${dist_container_name}"
    docker cp config.yaml  ${dist_container_name}:/config.yaml
    
    echo "Re-start ${dist_container_name}"
    docker restart ${dist_container_name}
    echo "Wait ${dist_container_name} logs for 30s"
    sleep 30
}


function check_error(){
    ret=`docker logs ${dist_container_name}|grep -i " ERROR "`
    if [[ X"" == X"${ret}" ]];then
        exit 0
    else
        echo "======== ERROR log For your check ========="
        docker logs ${dist_container_name}

        exit 1
    fi
}

re_create_container
check_error
